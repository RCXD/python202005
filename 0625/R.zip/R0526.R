library(foreign)
raw_welfare <- read.spss("./data/Koweps_hpc10_2015_beta1.sav", to.data.frame = T)
welfare <- raw_welfare # 사본을 만든다.
library(dplyr)
# 코드표를 참조해서 열 이름을 변경한다.
welfare <- rename(welfare, gender = h10_g3)        # 성별
welfare <- rename(welfare, birth = h10_g4)         # 태어난 연도
welfare <- rename(welfare, marriage = h10_g10)     # 혼인상태
welfare <- rename(welfare, religion = h10_g11)     # 종교
welfare <- rename(welfare, code_job = h10_eco9)    # 직종코드
welfare <- rename(welfare, income = p1002_8aq1)    # 급여
welfare <- rename(welfare, code_region = h10_reg7) # 지역코드
# 성별 전처리
welfare$gender <- ifelse(welfare$gender == 9, NA, welfare$gender)
welfare$gender <- ifelse(welfare$gender == 1, "male", "female")
# 급여 전처리
welfare$income <- ifelse(welfare$income < 1 | welfare$income > 9998, NA,
                         welfare$income)
# 태어난 년도 전처리
welfare$birth <- ifelse(welfare$birth == 9999, NA, welfare$birth)
welfare$birth <- ifelse(welfare$birth < 1900 | welfare$birth > 2014, NA,
                        welfare$birth)
# 파생 변수를 만들어 나이 저장
welfare$age <- 2015 - welfare$birth
# 파생 변수를 만들어 연령대 저장
welfare <- welfare %>% 
  mutate(
    age_group = ifelse(age < 30, "young", ifelse(age < 60, "middle", "old"))
  )

# ===============================================================================

# 성별별 급여 차이는 어떤 연령대에서 가장 클까?

# 연령대별, 성별별 평균 급여표를 만든다.
ageGroup_gender_income <- welfare %>% 
  filter(!is.na(income)) %>% 
  group_by(age_group, gender) %>% 
  summarise(mean_income = mean(income))

library(ggplot2)
ggplot(data = ageGroup_gender_income, aes(x = age_group, y = mean_income)) +
  geom_col() +
  scale_x_discrete(limit = c("young", "middle", "old"))

# 축을 만드는 aes() 함수에 fill 옵션을 지정하면 그룹이 2개 이상일 경우 그룹별로
# 색을 다르게 출력할 수 있다.
ggplot(data = ageGroup_gender_income, 
       aes(x = age_group, y = mean_income, fill = gender)) +
  geom_col() +
  scale_x_discrete(limit = c("young", "middle", "old"))

# geom_col() 함수에 position = "dodge" 옵션을 지정하면 그룹이 2개 이상일 경우
# 막대 그래프를 쌓아서 출력하지 않고 그룹별로 그래프를 출력한다.
ggplot(data = ageGroup_gender_income, 
       aes(x = age_group, y = mean_income, fill = gender)) +
  geom_col(position = "dodge") +
  scale_x_discrete(limit = c("young", "middle", "old"))

ggplot(data = ageGroup_gender_income, aes(x = gender, y = mean_income)) +
  geom_col() + 
  scale_x_discrete(limit = c("male", "female"))

ggplot(data = ageGroup_gender_income, 
       aes(x = gender, y = mean_income, fill = age_group)) +
  geom_col() + 
  scale_x_discrete(limit = c("male", "female"))

ggplot(data = ageGroup_gender_income, 
       aes(x = gender, y = mean_income, fill = age_group)) +
  geom_col(position = "dodge") + 
  scale_x_discrete(limit = c("male", "female"))

# ===============================================================================

# 성별별 급여 차이는 어떤 나이에서 가장 클까?

# 나이별, 성별별 평균 급여표를 만든다.
age_gender_income <- welfare %>% 
  filter(!is.na(income)) %>% 
  group_by(age, gender) %>% 
  summarise(mean_income = mean(income))

ggplot(data = age_gender_income, aes(x = age, y = mean_income)) + 
  geom_col()

ggplot(data = age_gender_income, aes(x = age, y = mean_income, fill = gender)) + 
  geom_col()

ggplot(data = age_gender_income, aes(x = age, y = mean_income, fill = gender)) + 
  geom_col(position = "dodge")

# ===============================================================================

# 어떤 직업이 가장 급여를 많이 받을까?

# 직업 전처리
class(welfare$code_job)
table(welfare$code_job)

# 코드북(Koweps_Codebook.xlsx) 파일의 2번째 시트의 데이터르 읽어온다.
library(readxl)
job_list <- read_excel("./data/Koweps_Codebook.xlsx", sheet = 2)

welfare_job <- welfare
# left_join() 함수로 welfare_job에 job_list를 결합시킨다.
welfare_job <- left_join(welfare_job, job_list, by = "code_job")
welfare_job$job
table(is.na(welfare_job$code_job))
table(is.na(welfare_job$job))

# 직업 코드나 직업 또는 급여가 NA가 아닌 데이터만 추출해서 작업한다.
welfare_job %>% 
  filter(!is.na(code_job) & !is.na(income)) %>% 
  select(code_job, job, income)

# 직업 종류가 너무 많기 때문에 평균 급여를 내림차순으로 정렬해서 35개만 뽑아낸
# 후 작업한다.
job_income_top35 <- welfare_job %>% 
  filter(!is.na(code_job) & !is.na(income)) %>% 
  select(code_job, job, income) %>% 
  group_by(job) %>% 
  summarise(mean_income = mean(income)) %>% 
  arrange(desc(mean_income)) %>% 
  head(35)
  
ggplot(data = job_income_top35, aes(x = job, y = mean_income)) +
  geom_col()

ggplot(data = job_income_top35, aes(x = reorder(job, mean_income), 
                                    y = mean_income)) +
  geom_col()

ggplot(data = job_income_top35, aes(x = reorder(job, -mean_income), 
                                    y = mean_income)) +
  geom_col()

# x축 레이블에 표시되는 직업의 이름이 너무 길어서 겹쳐 보이기 때문에 읽을 수
# 없는 경우 coord_flip() 함수를 사용해 차트를 회전시켜 출력할 수 있다.
ggplot(data = job_income_top35, aes(x = job, y = mean_income)) +
  geom_col() +
  coord_flip() +
  ylim(0, 1000) +
  xlab("직업") +       # x축 제목
  ylab("평균 급여") +  # y축 제목
  ggtitle("직업별 상위 35개의 평균 급여 그래프")  # 차트 제목

ggplot(data = job_income_top35, aes(x = reorder(job, mean_income), 
                                    y = mean_income)) +
  geom_col() +
  coord_flip()

ggplot(data = job_income_top35, aes(x = reorder(job, -mean_income), 
                                    y = mean_income)) +
  geom_col() +
  coord_flip()

# 어떤 직업이 가장 급여를 적게 받을까?
job_income_bottom35 <- welfare_job %>% 
  filter(!is.na(code_job) & !is.na(income)) %>% 
  select(code_job, job, income) %>% 
  group_by(job) %>% 
  summarise(mean_income = mean(income)) %>% 
  arrange(mean_income) %>% 
  head(35)

ggplot(data = job_income_bottom35, aes(x = job, y = mean_income)) +
  geom_col() +
  coord_flip() +
  ylim(0, 1000) +
  xlab("직업") + 
  ylab("평균 급여") + 
  ggtitle("직업별 하위 35개의 평균 급여 그래프")

# ===============================================================================

# 직업이 "정보시스템 개발 전문가(0222)"일 경우 나이별 평균 급여는 얼마인가?

info_dev <- welfare_job %>% 
  filter(code_job == 222 & !is.na(income)) %>% 
  group_by(age) %>% 
  summarise(mean_income = mean(income))

ggplot(data = info_dev, aes(x = age, y = mean_income)) +
  geom_col()

# 직업이 "정보시스템 개발 전문가(0222)"일 경우 나이별, 성별별 평균 급여는 얼마인가?
info_dev_gender <- welfare_job %>% 
  filter(code_job == 222 & !is.na(income)) %>% 
  group_by(age, gender) %>% 
  summarise(mean_income = mean(income))

ggplot(data = info_dev_gender, aes(x = age, y = mean_income, fill = gender)) +
  geom_col()
ggplot(data = info_dev_gender, aes(x = age, y = mean_income, fill = gender)) +
  geom_col(position = "dodge")

# ===============================================================================

# 성별별로 어떤 직업에 종사하는 사람이 많을까?

# 성별별 직업 빈도표를 만든다.
job_gender <- welfare_job %>% 
  filter(!is.na(job)) %>% 
  group_by(job, gender) %>% 
  summarise(n = n()) %>% 
  arrange(desc(n)) %>% 
  head(35)

ggplot(data = job_gender, aes(x = job, y = n)) +
  geom_col()
ggplot(data = job_gender, aes(x = reorder(job, n), y = n)) +
  geom_col()
ggplot(data = job_gender, aes(x = reorder(job, -n), y = n)) +
  geom_col()
ggplot(data = job_gender, aes(x = reorder(job, n), y = n, fill = gender)) +
  geom_col()
ggplot(data = job_gender, aes(x = reorder(job, n), y = n, fill = gender)) +
  geom_col(position = "dodge")
ggplot(data = job_gender, aes(x = reorder(job, n), y = n, fill = gender)) +
  geom_col(position = "dodge") +
  coord_flip()

# coord_flip()를 사용해서 그래프를 회전시키지 않고 theme() 함수를 사용해서 x축
# 레이블을 회전 시킬 수 있다.
ggplot(data = job_gender, aes(x = reorder(job, n), y = n, fill = gender)) +
  geom_col(position = "dodge") +
  theme(axis.text.x = element_text(angle = -90)) +
  xlab("직업") +
  ylab("인원수")
  
# 남자 직업 빈도표를 만든다.
job_gender_male <- welfare_job %>% 
  filter(!is.na(job) & gender == "male") %>% 
  group_by(job) %>% 
  summarise(n = n()) %>% 
  arrange(desc(n)) %>% 
  head(35)

ggplot(data = job_gender_male, aes(x = reorder(job, n), y = n)) +
  geom_col(position = "dodge") +
  coord_flip() +
  xlab("직업") +
  ylab("인원수")

# 여자 직업 빈도표를 만든다.
job_gender_female <- welfare_job %>% 
  filter(!is.na(job) & gender == "female") %>% 
  group_by(job) %>% 
  summarise(n = n()) %>% 
  arrange(desc(n)) %>% 
  head(35)

ggplot(data = job_gender_female, aes(x = reorder(job, n), y = n)) +
  geom_col(position = "dodge") +
  coord_flip() +
  xlab("직업") +
  ylab("인원수")

# 남자 연령대("young") 직업 빈도표를 만든다.
job_gender_male_young <- welfare_job %>% 
  filter(!is.na(job) & gender == "male" & age_group == "young") %>% 
  group_by(job) %>% 
  summarise(n = n()) %>% 
  arrange(desc(n)) %>% 
  head(35)

ggplot(data = job_gender_male_young, aes(x = reorder(job, n), y = n)) +
  geom_col(position = "dodge") +
  coord_flip() +
  xlab("직업") +
  ylab("인원수")

# 남자 연령대("middle") 직업 빈도표를 만든다.
job_gender_male_middle <- welfare_job %>% 
  filter(!is.na(job) & gender == "male" & age_group == "middle") %>% 
  group_by(job) %>% 
  summarise(n = n()) %>% 
  arrange(desc(n)) %>% 
  head(35)

ggplot(data = job_gender_male_middle, aes(x = reorder(job, n), y = n)) +
  geom_col(position = "dodge") +
  coord_flip() +
  xlab("직업") +
  ylab("인원수")

# 남자 연령대("old") 직업 빈도표를 만든다.
job_gender_male_old <- welfare_job %>% 
  filter(!is.na(job) & gender == "male" & age_group == "old") %>% 
  group_by(job) %>% 
  summarise(n = n()) %>% 
  arrange(desc(n)) %>% 
  head(35)

ggplot(data = job_gender_male_old, aes(x = reorder(job, n), y = n)) +
  geom_col(position = "dodge") +
  coord_flip() +
  xlab("직업") +
  ylab("인원수")

# 여자 연령대("young") 직업 빈도표를 만든다.
job_gender_female_young <- welfare_job %>% 
  filter(!is.na(job) & gender == "female" & age_group == "young") %>% 
  group_by(job) %>% 
  summarise(n = n()) %>% 
  arrange(desc(n)) %>% 
  head(35)

ggplot(data = job_gender_female_young, aes(x = reorder(job, n), y = n)) +
  geom_col(position = "dodge") +
  coord_flip() +
  xlab("직업") +
  ylab("인원수")

# 여자 연령대("middle") 직업 빈도표를 만든다.
job_gender_female_middle <- welfare_job %>% 
  filter(!is.na(job) & gender == "female" & age_group == "middle") %>% 
  group_by(job) %>% 
  summarise(n = n()) %>% 
  arrange(desc(n)) %>% 
  head(35)

ggplot(data = job_gender_female_middle, aes(x = reorder(job, n), y = n)) +
  geom_col(position = "dodge") +
  coord_flip() +
  xlab("직업") +
  ylab("인원수")

# 여자 연령대("old") 직업 빈도표를 만든다.
job_gender_female_old <- welfare_job %>% 
  filter(!is.na(job) & gender == "female" & age_group == "old") %>% 
  group_by(job) %>% 
  summarise(n = n()) %>% 
  arrange(desc(n)) %>% 
  head(35)

ggplot(data = job_gender_female_old, aes(x = reorder(job, n), y = n)) +
  geom_col(position = "dodge") +
  coord_flip() +
  xlab("직업") +
  ylab("인원수")

# ===============================================================================

# 종교가 있는 사람은 이혼을 덜 할까?

# 종교 전처리
table(welfare$religion)
welfare$religion <- ifelse(welfare$religion == 9, NA, welfare$religion)
welfare$religion <- ifelse(welfare$religion == 1 | welfare$religion == 2, 
                           welfare$religion, NA)
welfare$religion <- ifelse(welfare$religion %in% c(1, 2), welfare$religion, NA)

welfare$religion <- ifelse(welfare$religion == 1, "yes", "no")

# 혼인상태 전처리
table(welfare$marriage)
welfare$marriage <- ifelse(welfare$marriage == 9, NA, welfare$marriage)
# 혼인상태 데이터는 다른 작업에 사용할 수 있으므로 원래 데이터는 그대로 유지시키고
# 파생 변수를 만들어 혼인 상태를 저장한다.
welfare$group_marriage <- ifelse(welfare$marriage %in% c(1, 4), "marriage",
                                 ifelse(welfare$marriage == 3, "divorce", NA))
table(welfare$group_marriage)
table(is.na(welfare$group_marriage))

# 종교 유무에 따른 이혼율 표를 만든다.
religion_marriage <- welfare %>% 
  filter(!is.na(group_marriage)) %>% # 결혼(별거 포함), 이혼만 추출
  group_by(religion, group_marriage) %>% # 종교 유무별 혼인 상태 그룹화
  summarise(n = n()) %>% # 종교 유무별 혼인 상태에 따른 인원수 계산
  mutate(pct = round(n / sum(n) * 100, 1))
# round(반올림 할 숫자 데이터, 반올림 후 화면에 표시할 자리수)
# 화면에 표시할 자리수는 아래와 같이 지정한다.
# 자리수 : -3  -2  -1   0     1   2   3
# 숫  자 :  1   2   3   4  .  5   6   7

ggplot(data = religion_marriage, aes(x = group_marriage, y = pct, 
                                     fill = religion)) +
  geom_col(position = "dodge")
ggplot(data = religion_marriage, aes(x = religion, y = pct, 
                                     fill = group_marriage)) +
  geom_col(position = "dodge")




