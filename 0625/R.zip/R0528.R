# 국정원 트윗 데이터 분석하기

# twitter.csv 파일을 읽어온다.
# csv 파일을 읽을 때 invalid multibyte string 3 에러가 발생되면 fileEncoding 옵션을
# UTF-8로 지정해서 읽어들이면 된다.
twitter <- read.csv("./data/twitter.csv", fileEncoding = "UTF-8", header = T,
                    stringsAsFactors = F)
class(twitter)
str(twitter)

# 데이터프레임의 변수 이름을 영어로 변경한다.
library(dplyr)
twitter <- rename(twitter, no = 번호, id = 계정이름, writeDate = 작성일, tw = 내용)

# 특수문자와 제어문자를 없앤다.
twitter$tw <- gsub("[[:punct:][:cntrl:]]", "", twitter$tw)

# 트윗 데이터를 형태소 분석을 한다.
library(KoNLP)
nouns <- extractNoun(twitter$tw)
class(nouns)
nouns <- unlist(nouns)

# 단어별 출현 빈도수를 계산하고 데이터프레임으로 만든다.
wordCount <- table(nouns)
class(wordCount)
df_wordCount <- as.data.frame(wordCount)
class(df_wordCount)
str(df_wordCount)

# 데이터프레임의 변수 이름을 수정하고 2글자 이상 6글자 이하인 단어만 뽑아낸다.
df_wordCount <- rename(df_wordCount, words = nouns, freq = Freq)
df_wordCount$words <- gsub("^[0-9]*$", "", df_wordCount$words)
df_wordCount$words <- gsub("들이", "", df_wordCount$words)
df_wordCount$words <- gsub("하게", "", df_wordCount$words)
df_wordCount$words <- gsub("하지", "", df_wordCount$words)
df_wordCount$words <- gsub("하기", "", df_wordCount$words)
df_wordCount$words <- gsub("이유", "", df_wordCount$words)
df_wordCount$words <- gsub("때문", "", df_wordCount$words)
df_wordCount$words <- gsub("비롯", "", df_wordCount$words)

top200 <- df_wordCount %>% 
  filter(nchar(words) >= 2 & nchar(words) <= 6) %>% 
  arrange(desc(freq)) %>% 
  head(200)

# 워드 클라우드를 만든다.
library(wordcloud)
library(RColorBrewer)
pal <- brewer.pal(8, "Dark2")
set.seed(3)
wordcloud(
  words = top200$words, # 워드 클라우드로 표시할 단어 목록
  freq = top200$freq,   # 워드 클라우드에 표시할 단어의 출현 빈도수
  min.freq = 2,         # 워드 클라우드에 표시할 단어의 최소 개수
  max.words = 200,      # 워드 클라우드에 표시할 단어의 최대 개수
  rot.per = 0.1,        # 워드 클라우드에 표시되는 단어의 회전 비율
  random.order = F,     # 출현 빈도가 높은 단어를 중앙에 배치한다.
  scale = c(7, 0.5),    # 워드 클라우드에 표시되는 단어의 크기 범위
  colors = pal          # 단어에 표시할 색상 목록이 저장된 팔레트
)

# ===============================================================================

twitter <- read.csv("./data/twitter.csv", fileEncoding = "UTF-8", header = T,
                    stringsAsFactors = F)
twitter <- rename(twitter, no = 번호, id = 계정이름, writeDate = 작성일, tw = 내용)
twitter$tw <- gsub("[[:punct:][:cntrl:]]", "", twitter$tw)
nouns <- extractNoun(twitter$tw)
nouns <- unlist(nouns)
wordCount <- table(nouns)
df_wordCount <- as.data.frame(wordCount)
df_wordCount <- rename(df_wordCount, words = nouns, freq = Freq)
df_wordCount$words <- gsub("^[0-9]*$", "", df_wordCount$words)
top20 <- df_wordCount %>% 
  filter(nchar(words) >= 2 & nchar(words) <= 6) %>% 
  arrange(desc(freq)) %>% 
  head(20)

library(ggplot2)
order_desc <- arrange(top20, desc(freq)) # 차트 출력 순서
ggplot(top20, aes(words, freq)) + 
  geom_col() +
  coord_flip() +
  ylim(0, 2500) +
  scale_x_discrete(limit = order_desc$words) +
  xlab("단어") +
  ylab("빈도수") +
  ggtitle("국정원 트윗 분석") +
  # 차트의 고유 값을 표시한다.
  geom_text(aes(label = freq), hjust = -0.5, color = "#FF0000") 

order_asc <- arrange(top20, freq)

# ===============================================================================

# 단계 구분도
# 단계 구분도는 지역별 통계치를 색깔의 차이로 표현한 지도를 말한다.
# 단계 구분도를 만들려면 지역별 위도, 경도 정보가 저장된 지도 데이터가 필요하기
# 때문에 maps 패키지의 미국 주별 위도, 경도를 저장해 놓은 state 데이터를 사용한다.
install.packages("maps")
library(maps)

# ggplot2 패키지의 map_data() 함수로 지도 데이터를 불러온다.
states_map <- map_data('state')
head(states_map)

# 미국 주별 강력 범죄율 데이터(USArrests) 단계 구분도 만들기
# USArrests => 1973년 미국 주별 강력 범죄율 정보
class(USArrests)
head(USArrests)

# USArrests 데이터의 행 이름을 tibble 패키지의 rownames_to_column() 함수를 사용해
# 적당한 열 이름을 가지는 데이터프레임으로 만든다.
# tibble 패키지는 dplyr 패키지가 설치될 때 자동으로 설치되는 패키지이므로 별도의
# 설치 과정 없이 로드만 하면 된다.
library(tibble)

# rownames_to_column() 함수는 행 이름을 var 옵션에서 지정한 변수명으로 데이터화
# 하고 새로 1부터 시작하는 행 이름을 붙여준다.
# rownames_to_column(데이터프레임, var = "변수이름")
crime <- rownames_to_column(USArrests, var = "state")
head(crime)

# 지도 데이터의 지역명은 모두 소문자이므로 crime의 지역명을 tolower() 함수를
# 사용해서 모두 소문자로 만든다. => toupper() 함수는 모두 대문자로 변환한다.
crime$state <- tolower(crime$state)

# ggiraphExtra 패키지의 ggChoropleth() 함수를 사용해 단계 구분도를 만든다.
install.packages("ggiraphExtra")
library(ggiraphExtra)
install.packages("mapproj")
library(mapproj)

ggChoropleth(
  data = crime,        # 단계 구분도로 표시할 데이터
  aes(fill = Murder,   # 데이터로 사용할 변수
      map_id = state), # 지도 데이터의 지역이 저장된 변수
  map = states_map     # 지도 데이터(경도, 위도 정보)
)
ggChoropleth(data = crime, aes(fill = Assault, map_id = state), map = states_map)
ggChoropleth(data = crime, aes(fill = Rape, map_id = state), map = states_map)

# ===============================================================================

# 대한민국 시도별 인구, 결핵 환자 수 단계 구분도 만들기
# kormaps2014 패키지를 이용하면 대한민국의 지역 통계 데이터와 지도 데이터를
# 사용할 수 있다.
# 어떤 패키지들은 CRAN에 등록되어있지 않고 github를 통해서 공유된다.
# install.packages("kormaps2014")를 실행해서 설치할 수 없다.
# github에 공유된 kormaps2014 패키지를 다운받아 사용하려면 devtools 패키지를
# 설치하고 다운받아 사용한다.
install.packages("devtools")
library(devtools)

# devtools 패키지의 install_github() 함수로 kormaps2014 패키지를 설치한다.
install_github("cardiomoon/kormaps2014")
library(kormaps2014)

# 지도 데이터 => kormap1(시도별), kormap2(시구군별), kormap3(읍면동별)
head(kormap1)
# 한글이 깨져서 보이면 kormaps2014 패키지의 changeCode() 함수를 사용해 출력하면
# UTF-8로 인코딩된 한글을 CP949 타입으로 변환해서 깨지지 않게 출력한다.
head(changeCode(kormap1))
# 인구 데이터 => korpop1(시도별), korpop2(시구군별), korpop3(읍면동별)
head(korpop1)
head(changeCode(korpop1))

str(changeCode(kormap1))
str(changeCode(korpop1))
# 변수 이름이 한글일 경우 오동작을 일으킬 수 있으므로 지도 작성에 사용할 변수의
# 이름을 rename() 함수를 사용해서 영문으로 변환한다.
korpop1_kr <- korpop1
korpop1_kr <- rename(korpop1_kr, name = 행정구역별_읍면동, pop = 총인구_명)
str(changeCode(korpop1_kr))

library(ggplot2)
library(ggiraphExtra)
library(mapproj)

# ggChoropleth() 함수로 만든 단계 구분도에서 한글이 깨져보이면 options() 함수를
# 이용해 UTF-8로 인코딩 시킨다. => 원상 복구는 CP949로 인코딩하면 된다.
# options() 함수는 R을 다시 시작하면 원래 상태로 초기화된다.
options(encoding = "UTF-8")

# kormap1과 korpop1_kr을 이용해 단계 구분도를 만든다.
ggChoropleth(data = korpop1_kr, aes(fill = pop, map_id = code), map = kormap1)
# 단계 구분도 위에 마우스를 올렸을 때 tooltip을 표시되게 하려면 aes() 함수의
# tooltip 속성에 tooltip으로 사용할 변수명을 적어주고 interactive = T 속성을
# 지정하면 된다.
ggChoropleth(data = korpop1_kr, aes(fill = pop, map_id = code, tooltip = name),
             map = kormap1, interactive = T)

# ===============================================================================

# 위와 같은 방법으로 실행했는데 interactive 그래프에 tooltip의 한글이 깨지면
# 아래와 같은 방법으로 한다.

# areacode : kormaps2014 패키지에서 지역 코드에 따른 지역 이름이 저장된 데이터
# 프레임
areacode <- kormaps2014::areacode
changeCode(areacode)
korpop1_kr2 <- korpop1
str(changeCode(korpop1_kr2))

# left_join() 함수를 사용해 korpop1_kr2와 areacode를 합친다.
class(korpop1_kr2$code)
class(areacode$code)
# korpop1_kr2의 code는 character 타입이고 areacode의 code는 integer 타입이기 때문에
# 에러가 발생된다.
# areacode의 code를 as.character() 함수를 사용해서 character 타입으로 변환한다.
areacode_kr <- areacode
areacode_kr$code <- as.character(areacode_kr$code)
class(areacode_kr$code)
# korpop1_kr2의 code와 areacode_kr의 code를 합친다.
korpop1_kr2 <- left_join(korpop1_kr2, changeCode(areacode_kr), by = "code")
korpop1_kr2 <- rename(korpop1_kr2, pop = 총인구_명)
str(changeCode(korpop1_kr2))

ggChoropleth(data = korpop1_kr2, aes(fill = pop, map_id = code), map = kormap1)
str(changeCode(korpop1_kr2))
ggChoropleth(data = korpop1_kr2, aes(fill = pop, map_id = code, tooltip = name1),
             map = kormap1, interactive = T)

# ===============================================================================

library(kormaps2014)
library(dplyr)
library(maps)
library(ggiraphExtra)
library(mapproj)
library(ggplot2)

korpop2_kr <- korpop2
korpop2_kr <- rename(korpop2_kr, name = 행정구역별_읍면동, pop = 총인구_명)
ggChoropleth(data = korpop2_kr, aes(fill = pop, map_id = code), map = kormap2)
ggChoropleth(data = korpop2_kr, aes(fill = pop, map_id = code, tooltip = name),
             map = kormap2, interactive = T)

korpop3_kr <- korpop3
korpop3_kr <- rename(korpop3_kr, name = 행정구역별_읍면동, pop = 총인구_명)
ggChoropleth(data = korpop3_kr, aes(fill = pop, map_id = code), map = kormap3)
ggChoropleth(data = korpop3_kr, aes(fill = pop, map_id = code, tooltip = name),
             map = kormap3, interactive = T)

# ===============================================================================

korpop2_kr2 <- korpop2
class(korpop2_kr2$code)
areacode_kr2 <- korpop2_kr2 %>% 
  select(code, 행정구역별_읍면동) %>% 
  rename(name = 행정구역별_읍면동)
changeCode(areacode_kr2)
class(areacode_kr2$code)
areacode_kr2$code <- as.character(areacode_kr2$code)
korpop2_kr2 <- left_join(korpop2_kr2, changeCode(areacode_kr2), by = "code")
korpop2_kr2 <- rename(korpop2_kr2, pop = 총인구_명)
ggChoropleth(data = korpop2_kr2, aes(fill = pop, map_id = code), map = kormap2)
ggChoropleth(data = korpop2_kr2, aes(fill = pop, map_id = code, tooltip = name), 
             map = kormap2, interactive = T)

korpop3_kr2 <- korpop3
class(korpop3_kr2$code)
areacode_kr3 <- korpop3_kr2 %>% 
  select(code, 행정구역별_읍면동) %>% 
  rename(name = 행정구역별_읍면동)
changeCode(areacode_kr3)
class(areacode_kr3$code)
areacode_kr3$code <- as.character(areacode_kr3$code)
korpop3_kr2 <- left_join(korpop3_kr2, changeCode(areacode_kr3), by = "code")
korpop3_kr2 <- rename(korpop3_kr2, pop = 총인구_명)
ggChoropleth(data = korpop3_kr2, aes(fill = pop, map_id = code), map = kormap3)
ggChoropleth(data = korpop3_kr2, aes(fill = pop, map_id = code, tooltip = name), 
             map = kormap3, interactive = T)


