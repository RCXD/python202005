library(dplyr)
library(ggplot2)

# ggplot2 패키지를 이용해 그래프 그리기
# ggplot2의 그래프를 작성하는 방법은 레이어 구조를 사용한다.
# 배경을 먼저 만들고 배경위에 그래프를 그린고 그 위에 축, 색, 표식 등을 추가해서
# 그래프를 완성한다.

# 산점도 : 연속된 값으로 되어있는 두 변수간의 관계를 표시한다.
# 그래프가 출력될 배경을 만든다.
# ggplot(data = 데이터프레임, aes(x = x(가로)축, y = y(세로)축))
ggplot(data = mpg, aes(x = displ, y = hwy))
# 배경을 만든 후 geom_그래프이름() 함수를 "+"로 연결해서 배경에 그래프를 넣어준다.
ggplot(data = mpg, aes(x = displ, y = hwy)) + geom_point()
ggplot(data = mpg, aes(x = displ, y = cty)) + geom_point()
ggplot(data = mpg, aes(x = hwy, y = cty)) + geom_point()
# 완성된 그래프에 축, 색, 표식 등을 추가한다.
ggplot(data = mpg, aes(x = displ, y = hwy)) + 
  geom_point() +
  xlim(3, 6) + # x축의 표시 범위를 지정한다.
  ylim(10, 30) # y축의 표시 범위를 지정한다.

# 막대 그래프 : 데이터의 크기를 막대로 표시한다.

# 구동 방식별 고속도로 연비 평균
ggplot(data = mpg, aes(x = drv, y = hwy)) + geom_col() # 합계 그래프
# 평균 그래프를 만들려면 dplyr 패키지를 사용해서 데이터를 정제해야 한다.
mpg_drv <- mpg %>% 
  group_by(drv) %>% 
  summarise(mean_hwy = mean(hwy))
ggplot(data = mpg_drv, aes(x = drv, y = mean_hwy)) + geom_col()

# 차종별 도시 연비 평균
ggplot(data = mpg, aes(x = class, y = cty)) + geom_col() # 합계 그래프
mpg_class <- mpg %>% 
  group_by(class) %>% 
  summarise(mean_cty = mean(cty))
ggplot(data = mpg_class, aes(x = class, y = mean_cty)) + geom_col()

# reorder() 함수를 사용하면 x축 항목의 정렬 순서를 변경할 수 있다.
# reorder(정렬할 데이터가 저장된 변수 이름, 정렬 기준으로 사용할 변수 이름)
# reorder(class, mean_cty) => class를 mean_cty의 오름차순으로 정렬한다.
ggplot(data = mpg_class, aes(x = reorder(class, mean_cty), y = mean_cty)) + 
  geom_col()
# 정렬 기준으로 사용할 변수 이름만 쓰면 오름차순으로 정렬되고 정렬 기준으로 사용할
# 변수 앞에 "-"를 붙여주면 내림차순으로 정렬된다.
ggplot(data = mpg_class, aes(x = reorder(class, -mean_cty), y = mean_cty)) + 
  geom_col()

# 어떤 회사에서 생산한 suv 자동차가 연비가 높은지 알아보기 위해 suv 차종을 대상으로
# 도시 연비 평균이 높은 다섯곳을 나타내는 막대 그래프를 연비가 높은 순서로 정렬해서
# 만든다.
mpg_suv <- mpg %>%                    # mpg 데이터 셋 에서
  filter(class == "suv") %>%          # 차종이 suv인 것만
  group_by(manufacturer) %>%          # 제조사 별로 그룹화 해서
  summarise(mean_cty = mean(cty)) %>% # 도시 연비 평균을 계산하고
  arrange(desc(mean_cty)) %>%         # 내림차순으로 정렬해
  head(5)                             # 상위 5건만 얻어낸다.

# 그래프 작성에 사용할 데이터를 dplyr 패키지의 함수를 이용해서 정렬시켜 얻어왔다
# 하다라도 그래프를 그릴 때 reorder() 함수를 사용하지 않으면 x축에 표시되는 레이블의
# 오름차순으로 정렬되서 출력된다.
ggplot(data = mpg_suv, aes(x = manufacturer, y = mean_cty)) + geom_col()
ggplot(data = mpg_suv, aes(x = reorder(manufacturer, mean_cty), y = mean_cty)) + 
  geom_col()
ggplot(data = mpg_suv, aes(x = reorder(manufacturer, -mean_cty), y = mean_cty)) + 
  geom_col()

# 빈도(개수) 막대 그래프 : x축만 지정하고 y축은 지정하지 않는다.

mpg_drv_n <- mpg %>% 
  group_by(drv) %>% 
  summarise(n = n())
ggplot(data = mpg, aes(x = drv)) + geom_bar()

mpg_class_n <- mpg %>% 
  group_by(class) %>% 
  summarise(n = n())
ggplot(data = mpg, aes(x = class)) + geom_bar()

# geom_col() : 합계 그래프가 기본적으로 작성된다. 평균 그래프를 작성하려면 원래
# 자료를 가공해서 요약한 평균 데이터를 이용해서 그래프를 그려야 한다.
# geom_bar() : 개수 그래프, 원래 자료의 데이터 개수만 가지고 그래프를 만든다.

# 선 그래프 : 시간에 따른 데이터 변화량을 보여주는 시계열 그래프를 작성한다.

# economics : ggplot2 패키지를 설치하면 제공되는 데이터
str(economics)
# date    : 날짜
# pce     : 개인 소비 지출
# pop     : 총 인구
# psavert : 개인 저축율
# uempmed : 실업 기간
# unemploy: 실업자 수

ggplot(data = economics, aes(x = date, y = uempmed)) + geom_line()
ggplot(data = economics, aes(x = date, y = psavert)) + geom_line()
ggplot(data = economics, aes(x = date, y = unemploy)) + geom_line()
ggplot(data = economics, aes(x = date, y = pce)) + geom_line()

# 특정 시계열 구간의 데이터를 추출해서 그래프를 작성할 수 있다.
economics_date <- subset(economics, date >= as.Date("2010-01-01") &
                           date <= as.Date("2015-04-01"))
ggplot(data = economics_date, aes(x = date, y = uempmed)) + geom_line()

# 선 그래프 속성 지정하기
ggplot(data = economics, aes(x = date, y = unemploy)) + 
  # color : 선 색, lwd : 선 두께
  geom_line(color = "#0000FF", lwd = 1) +
  # geom_hline() 함수는 그래프에 기준선을 그린다.
  # yintercept : 기준선을 그릴 위치, linetype : 선 종류
  geom_hline(yintercept = mean(economics$unemploy), linetype = "dashed",
             color = "#FF0000", lwd = 1)

# geom_bar() 함수로 그래프를 작성하고 stat = "identity" 속성을 지정하면 영역
# 그래프를 만들 수 있다.
ggplot(data = economics, aes(x = date, y = unemploy)) +
  geom_bar(color = "#FF00FF", lwd = 1, stat = "identity") +
  geom_hline(yintercept = mean(economics$unemploy), linetype = "dashed",
             color = "#0000FF", lwd = 1)

# 상자 그래프

ggplot(data = mpg, aes(x = drv, y = hwy)) + geom_boxplot()

# ===============================================================================

# 한국 복지 패널 데이터 분석하기
# 데이터가 통계 전용 소프트웨어인 SPSS, SAS, STATA 프로그램의 데이터 형태로 
# 제공되기 때문에 foreign 패키지로 R에서 사용할 수 있는 데이터 형태로 변환시킨
# 후 사용해야 한다.
install.packages("foreign")
library(foreign)

# foreign 패키지의 read.spss() 함수를 사용해 SPSS 타입의 데이터를 데이터프레임
# 형태로 R로 불러온다. => list 타입으로 읽어온다.
raw_welfare <- read.spss("./data/Koweps_hpc10_2015_beta1.sav")
class(raw_welfare) # list
# 그냥 읽어오면 list 타입으로 읽어오기 때문에 데이터프레임 형태로 읽어오기 위해서
# to.data.frame = T 옵션을 지정해서 읽어온다.
raw_welfare <- read.spss("./data/Koweps_hpc10_2015_beta1.sav", to.data.frame = T)
class(raw_welfare) # data.frame

# 사본을 만들어 작업한다.
welfare <- raw_welfare
str(welfare)
summary(welfare)
class(welfare)
head(welfare)
tail(welfare)
View(welfare)
dim(welfare) # 데이터프레임이 몇 행 몇 열인가 출력한다.

# Koweps_Codebook.xlsx(코드북) 파일을 참조해서 rename() 함수로 작업에 적절하게
# 변수의 이름을 변경한다.
welfare <- rename(welfare, gender = h10_g3) # 성별
welfare <- rename(welfare, birth = h10_g4) # 태어난 연도
welfare <- rename(welfare, marriage = h10_g10) # 혼인상태
welfare <- rename(welfare, religion = h10_g11) # 종교
welfare <- rename(welfare, code_job = h10_eco9) # 직종코드
welfare <- rename(welfare, income = p1002_8aq1) # 급여
welfare <- rename(welfare, code_region = h10_reg7) # 지역코드

# ===============================================================================

# 성별에 따른 급여 차이는 존재하는가?

# 성별 데이터 전처리
welfare$gender
class(welfare$gender)
table(welfare$gender)
welfare$gender <- ifelse(welfare$gender == 9, NA, welfare$gender)
table(is.na(welfare$gender))
welfare$gender <- ifelse(welfare$gender == 1, "male", "female")

# 급여 데이터 전처리
welfare$income
class(welfare$income)
table(welfare$income)
hist(welfare$income)
qplot(welfare$income)
boxplot(welfare$income)
# 급여는 1 ~ 9998 사이의 값을 가지므로 급여의 범위를 벗어나는 경우 결측치로 
# 처리한다.
welfare$income <- ifelse(welfare$income < 1 | welfare$income > 9998, NA,
                         welfare$income)
welfare$income <- ifelse(welfare$income >= 1 & welfare$income <= 9998,
                         welfare$income, NA)

# 성별에 따른 평균 급여 표를 만든다.
gender_income <- welfare %>% 
  filter(!is.na(income)) # 급여가 NA가 아닌 데이터만 추출한다.
table(is.na(gender_income$income))

gender_income <- welfare %>% 
  filter(!is.na(income)) %>% 
  group_by(gender) %>% 
  summarise(mean_income = mean(income))
ggplot(data = gender_income, aes(x = gender, y = mean_income)) +
  geom_col()

# ===============================================================================

# 몇 살때 급여를 가장 많이 받을까?

# 태어난 년도 전처리
welfare$birth
class(welfare$birth)
table(welfare$birth)
qplot(welfare$birth)
welfare$birth <- ifelse(welfare$birth == 9999, NA, welfare$birth)
welfare$birth <- ifelse(welfare$birth < 1900 | welfare$birth > 2014, NA,
                        welfare$birth)

# 나이를 기억하는 파생 변수를 만들어 나이를 저장한다.
welfare$age <- 2015 - welfare$birth
table(welfare$age)
qplot(welfare$age)

# 나이에 따른 급여 평균 표를 만든다.
age_income <- welfare %>% 
  filter(!is.na(income)) %>%
  group_by(age) %>% 
  summarise(mean_income = mean(income))
ggplot(data = age_income, aes(x = age, y = mean_income)) + geom_col()
ggplot(data = age_income, aes(x = age, y = mean_income)) + geom_line()

# ===============================================================================

# 어떤 연령대의 급여가 가장 많을까?

# 연령대(young => 1 ~ 29, middle => 30 ~ 59, old => 60 ~)를 기억하는 파생 변수를
# 만든다.
welfare <- welfare %>% 
  mutate(
    age_group = ifelse(age < 30, "young", 
                       ifelse(age < 60, "middle", "old"))
  )
class(welfare$age_group)
table(welfare$age_group)

# 연령대별 평균 급여 표를 만든다.
ageGroup_income <- welfare %>% 
  filter(!is.na(income)) %>%
  group_by(age_group) %>% 
  summarise(mean_income = mean(income))
ggplot(data = ageGroup_income, aes(x = age_group, y =  mean_income)) +
  geom_col()

ggplot(data = ageGroup_income, aes(x = reorder(age_group, mean_income), 
                                   y =  mean_income)) +
  geom_col()
ggplot(data = ageGroup_income, aes(x = reorder(age_group, -mean_income), 
                                   y =  mean_income)) +
  geom_col()

# scale_x_discrete() 함수를 사용해서 기본적으로 x축 레이블의 오름차순으로 정렬되서
# 작성되는 그래프의 x축 출력 순서를 변경할 수 있다.
# scale_x_discrete() 함수의 limit 속성에 c() 함수를 사용해 보고싶은 순서를
# 지정하면 된다.
ggplot(data = ageGroup_income, aes(x = reorder(age_group, mean_income), 
                                   y =  mean_income)) +
  geom_col() +
  scale_x_discrete(limit = c("young", "middle", "old"))
ggplot(data = ageGroup_income, aes(x = reorder(age_group, mean_income), 
                                   y =  mean_income)) +
  geom_col() +
  scale_x_discrete(limit = c("old", "middle", "young"))






