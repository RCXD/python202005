import requests

# 로그인 정보를 기억하는 딕셔너리
MEMBER_DATA = {
    "memberID": "mkvryu",
    "memberPassword": "1234"
}

# 세션(Session) 객체를 생성해 일시적으로 유지한다.
with requests.Session() as s:
    # 로그인 페이지로 POST 요청(Request) 객체를 생성하고 로그인 정보를 전달한다.
    # 로그인 후 메인 페이지로 리다이렉션(Redirection) 시키는 소스 코드가 리턴된다.
    request = s.post("http://dowellcomputer.com/member/memberLoginAction.jsp", data=MEMBER_DATA)
print(request.text)

    


