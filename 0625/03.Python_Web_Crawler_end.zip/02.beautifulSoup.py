import requests
# html 문서를 일고 파싱하기 위해 BeautifulSoup 모듈을 import 한다.
from bs4 import BeautifulSoup
request = requests.get("http://www.dowellcomputer.com/main.jsp")
html = request.text

# html 소스 코드를 BeautifulSoup 객체로 변환한다.
# parser 종류
# "html.parser" : html문서에 사용한다.
# "xml" : xml 파일에 사용한다.
soup = BeautifulSoup(html, "html.parser")
# print(type(soup)) # <class 'bs4.BeautifulSoup'>

# select() : 인수로 지정된 선택자에 해당되는 태그를 추출한다.
# 자식 선택자를 사용해 <td> 태그 아래의 모든 <a> 태그를 추출한다.
links = soup.select("td > a")
# print(links)
# 추출된 모든 <a> 태그의 개수만큼 반복하며 공지글을 추출한다.
for link in links:
    # print(link)
    # has_attr() : 태그가 특정 속성을 가지고 있으면 TRUE, 그렇치 않으면 FALSE
    # <a> 태그가 href 속성을 가지고 있다면
    if link.has_attr("href"):
        # get() : 태그의 특정 속성의 값을 얻어온다.
        # print(link.get("href"))
        # find() : 문자열에 인수로 지정된 문자열이 최초로 출현하는 위치를 얻어온다.
        # href 속성의 값으로 notice라는 문자열이 포함되어 있다면
        if link.get("href").find("notice") != -1:
            print(link.text)
