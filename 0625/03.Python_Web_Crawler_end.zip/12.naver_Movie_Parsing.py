from urllib.request import urlopen
from bs4 import BeautifulSoup

def parsing():
    url = 'https://movie.naver.com/movie/bi/mi/basic.nhn?code=132623'
    soup = BeautifulSoup(urlopen(url).read(), 'html.parser')

    # 좋아요
    review_good = soup.find('div', class_ = 'review_good')
    print(review_good.find('strong', class_ = 'good').get_text(), end = ' ')
    num_good = review_good.find('em', class_ = 'num_good')
    print(num_good.get_text())
    review = review_good.find_all('p')
    for good in review:
        print()
        print(good.get_text().strip())
    print('=' * 80)

    # 글쎄요
    review_bad = soup.find('div', class_ = 'review_bad')
    print(review_bad.find('strong', class_ = 'bad').get_text(), end = ' ')
    num_bad = review_bad.find('em', class_ = 'num_bad')
    print(num_bad.get_text())
    review = review_good.find_all('p')
    for bad in review:
        print()
        print(bad.get_text().strip())

if __name__ == '__main__':
    parsing()








