import urllib.request as request
from bs4 import BeautifulSoup

def searchWord():
    # urllib.request 라이브러리의 urlopen() 메소드로 파싱할 사이트에 접속하고
    # read() 메소드로 소스 코드를 읽어온다.
    sourcecode = request.urlopen("http://www.naver.com").read()
    soup = BeautifulSoup(sourcecode, "html.parser")
    list = []
    # BeautifulSoup 패키지의 find_all() 메소드로 class가 ah_h인 모든 <span> 태그의 읽는다.
    # 실시간 급상승 검색어가 2번 반복되어 소스 코드에 있기때문에 20번만 반복한다.
    for naver_text in soup.find_all("span", class_="ah_k")[:20]:
        list.append(naver_text.get_text())
    i = 0
    for naver_search in list:
        i += 1
        print("{}. {}".format(i, naver_search))

if __name__ == "__main__":
    searchWord()

