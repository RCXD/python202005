from bs4 import BeautifulSoup
import requests

# 한 건의 대화에 대한 정보를 담는 클래스
class Conversation:
    def __init__(self, question, answer): # 생성자
        self.question = question          # 질문을 기억하는 멤버 변수
        self.answer = answer              # 대답을 기억하는 멤버 변수
    def __str__(self):                    # 객체를 출력할 때 출력 서식 메소드
        return "질문: " + self.question + "\n답변: " + self.answer + "\n"

# 대화 주제를 파싱해서 리턴하는 함수
def get_subjects():
    subjects = []
    req = requests.get("https://basicenglishspeaking.com/daily-english-conversation-topics/")
    html = req.text
    soup = BeautifulSoup(html, "html.parser")
    divs = soup.findAll("div", {"class": "su-column-inner"})
    for div in divs:
        links = div.findAll("a")
        for link in links:
            # subject = link.text
            # 세부 대화 내용을 얻어오기 위해 <a> 태그의 텍스트가 아닌 href 속성 값을 얻어온다.
            # subject = link.get("href")[32:]
            subject = link.get("href")
            subjects.append(subject)
    return subjects
subjects = get_subjects()
print("총", len(subjects), "개의 대화를 찾았습니다.")

# 모든 대화 내용을 저장하는 빈 리스트를 선언한다.
conversations = []
i = 1 # 대화 주제 카운트 변수
# get_subjects() 함수로 파싱한 대화 주제 수 만큼 반복한다.
for sub in subjects:
    print("({} / {} {})".format(i, len(subjects), sub))
    # 각각의 대화 내용을 파싱할 페이지를 요청한다.
    # req  = requests.get("http://basicenglishspeaking.com/" + sub)
    req  = requests.get(sub)
    html = req.text
    soup = BeautifulSoup(html, "html.parser")
    # class 속성이 sc_player_container1인 모든 <div> 태그를 얻어온다.
    qnas = soup.findAll("div", {"class": "sc_player_container1"})
    # 각각의 주제에 대한 대화 내용 개수 만큼 반복한다.
    for qna in qnas:
        # index() : 객체의 인덱스 번호를 얻어온다.
        # print(qnas.index(qna))
        if qnas.index(qna) % 2 == 0:
            # next_sibling : 다음 형제 태그로 접근한다.
            # previous_sibling : 이전 형제 태그로 접근한다.
            # 인덱스가 짝수면 질문 변수에 질문을 넣고 다음 형제로 접근한다.
            q = qna.next_sibling
        else:
            # 인덱스가 홀수면 답변 변수에 답변을 넣고 다음 형제로 접근한다.
            a = qna.next_sibling
            c = Conversation(q, a)      # 질문과 답변으로 대화 객체를 생성한다.
            conversations.append(c)     # 생성된 대화 객체를 리스트에 추가한다.
    i = i + 1
print("총 ", len(conversations), "개의 대화를 찾았습니다.") # 681

for c in conversations:
    print(str(c))

