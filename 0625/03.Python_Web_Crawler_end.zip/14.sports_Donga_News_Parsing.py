from urllib.request import urlopen
from bs4 import BeautifulSoup

def parsing():
    url = 'https://sports.donga.com/News'
    soup = BeautifulSoup(urlopen(url).read(), 'html.parser')
    '''
    # 뉴스 제목 
    news_title = soup.find_all('span', class_ = 'tit')
    for title in news_title[3:-1]:
        print("=" * 80)
        print(i, title.get_text())
    print("=" * 50)
    
    # 뉴스 요약 
    news_summary = soup.find_all('span', class_ = 'desc')
    for summary in news_summary:
        print("=" * 80)
        print(i, summary.get_text())
    print("=" * 50)
    '''
    # 뉴스 상세    
    
    news_content = soup.find_all('span', class_ = 'desc')
    for i in range(len(news_content)):
        print("=" * 80)
        # print(news_content[i].find('a')['href'])
        link = news_content[i].find('a')['href']
        news_list = BeautifulSoup(urlopen(link).read(), 'html.parser')
        articlePhoto_len = 0
        if news_list.find('div', class_ = 'articlePhoto'):
            articlePhoto_len = len(news_list.find('div', class_ = 'articlePhoto').get_text())
        # print(articlePhoto_len)
        news = news_list.find('div', class_ = 'article_word').get_text()[articlePhoto_len:]
        print(news.strip())
    print("=" * 80)
    
if __name__ == '__main__':
    parsing()








